import React, { useState, useEffect, useCallback } from 'react';
import KeyboardHeatmap from '@/components/KeyboardHeatmap';
import KeyHistory from '@/components/KeyHistory';
import TypingTest from '@/components/TypingTest';
import Header from '@/components/Header';
import Footer from '@/components/Footer';
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Button } from "@/components/ui/button";
import { useToast } from "@/hooks/use-toast";
import { Keyboard, Clock, Eye } from "lucide-react";

interface KeyPress {
  key: string;
  timestamp: number;
}

interface TypingResult {
  wpm: number;
  accuracy: number;
  date: Date;
}

const Index = () => {
  // Active keys state (for keyboard visualization)
  const [activeKeys, setActiveKeys] = useState<Set<string>>(new Set());
  
  // Key press data
  const [keyPressData, setKeyPressData] = useState<Record<string, number>>({});
  const [totalKeyPresses, setTotalKeyPresses] = useState<number>(0);
  const [keyPressRate, setKeyPressRate] = useState<number>(0);
  const [recentKeyPresses, setRecentKeyPresses] = useState<KeyPress[]>([]);
  const [keyPressHistory, setKeyPressHistory] = useState<{ time: string, count: number }[]>([]);
  
  // Start/stop recording
  const [isRecording, setIsRecording] = useState<boolean>(false);
  const [sessionStartTime, setSessionStartTime] = useState<number | null>(null);
  
  // Typing test results
  const [typingResults, setTypingResults] = useState<TypingResult[]>([]);
  
  // For notifications
  const { toast } = useToast();
  
  // Initialize history
  useEffect(() => {
    // Create initial history of zero counts
    const initialHistory = Array.from({ length: 12 }, (_, i) => {
      const now = new Date();
      now.setSeconds(now.getSeconds() - (11 - i) * 5);
      return {
        time: now.toLocaleTimeString([], { 
          hour: '2-digit', 
          minute: '2-digit', 
          second: '2-digit',
          hour12: false 
        }),
        count: 0
      };
    });
    setKeyPressHistory(initialHistory);
  }, []);
  
  // Update key press rate
  useEffect(() => {
    if (!sessionStartTime) return;
    
    const intervalId = setInterval(() => {
      const elapsedMinutes = (Date.now() - sessionStartTime) / 60000;
      if (elapsedMinutes > 0) {
        setKeyPressRate(totalKeyPresses / elapsedMinutes);
      }
    }, 1000);
    
    return () => clearInterval(intervalId);
  }, [sessionStartTime, totalKeyPresses]);
  
  // Update history every 5 seconds
  useEffect(() => {
    if (!isRecording) return;
    
    const intervalId = setInterval(() => {
      const now = new Date();
      const timeString = now.toLocaleTimeString([], { 
        hour: '2-digit', 
        minute: '2-digit', 
        second: '2-digit',
        hour12: false 
      });
      
      setKeyPressHistory(prev => {
        // Keep most recent 12 entries
        const newHistory = [...prev.slice(-11), { time: timeString, count: totalKeyPresses }];
        return newHistory;
      });
    }, 5000);
    
    return () => clearInterval(intervalId);
  }, [isRecording, totalKeyPresses]);
  
  // Handle key down event
  const handleKeyDown = useCallback((e: KeyboardEvent) => {
    if (!isRecording) return;
    
    // Skip handling if the key press is related to recording toggle
    if (e.key === ' ' && (e.target === document.body || e.target === document.documentElement)) {
      // Don't do anything special for spacebar - let it be processed normally
      // This prevents the spacebar from toggling recording when pressed in text inputs
    }
    
    // Get normalized key name
    let keyName = e.key;
    if (keyName === ' ') keyName = 'Space';
    else if (keyName === 'Shift') keyName = 'Shift';
    else if (keyName === 'Control') keyName = 'Ctrl';
    else if (keyName === 'Alt') keyName = 'Alt';
    else if (keyName === 'Meta') keyName = 'Meta';
    else if (keyName === 'CapsLock') keyName = 'Caps';
    else if (keyName === 'Tab') keyName = 'Tab';
    else if (keyName === 'Backspace') keyName = 'Backspace';
    else if (keyName === 'Enter') keyName = 'Enter';
    else if (keyName === 'Escape') keyName = 'Esc';
    else if (keyName.length === 1) keyName = keyName.toUpperCase();
    
    // Update active keys
    setActiveKeys(prev => {
      const newKeys = new Set(prev);
      newKeys.add(keyName);
      return newKeys;
    });
    
    // Update key press data
    setKeyPressData(prev => {
      const newData = { ...prev };
      newData[keyName] = (newData[keyName] || 0) + 1;
      return newData;
    });
    
    // Update total key presses
    setTotalKeyPresses(prev => prev + 1);
    
    // Update recent key presses
    setRecentKeyPresses(prev => {
      const newPresses = [
        { key: keyName, timestamp: Date.now() },
        ...prev.slice(0, 19) // keep only 20 most recent
      ];
      return newPresses;
    });
  }, [isRecording]);
  
  // Handle key up event
  const handleKeyUp = useCallback((e: KeyboardEvent) => {
    if (!isRecording) return;
    
    // Get normalized key name
    let keyName = e.key;
    if (keyName === ' ') keyName = 'Space';
    else if (keyName === 'Shift') keyName = 'Shift';
    else if (keyName === 'Control') keyName = 'Ctrl';
    else if (keyName === 'Alt') keyName = 'Alt';
    else if (keyName === 'Meta') keyName = 'Meta';
    else if (keyName === 'CapsLock') keyName = 'Caps';
    else if (keyName === 'Tab') keyName = 'Tab';
    else if (keyName === 'Backspace') keyName = 'Backspace';
    else if (keyName === 'Enter') keyName = 'Enter';
    else if (keyName === 'Escape') keyName = 'Esc';
    else if (keyName.length === 1) keyName = keyName.toUpperCase();
    
    // Remove from active keys
    setActiveKeys(prev => {
      const newKeys = new Set(prev);
      newKeys.delete(keyName);
      return newKeys;
    });
  }, [isRecording]);
  
  // Add and remove event listeners
  useEffect(() => {
    if (isRecording) {
      window.addEventListener('keydown', handleKeyDown);
      window.addEventListener('keyup', handleKeyUp);
      
      if (!sessionStartTime) {
        setSessionStartTime(Date.now());
      }
      
      // Show toast notification
      toast({
        title: "Recording started",
        description: "Your keyboard activity is now being tracked."
      });
    } else {
      window.removeEventListener('keydown', handleKeyDown);
      window.removeEventListener('keyup', handleKeyUp);
    }
    
    return () => {
      window.removeEventListener('keydown', handleKeyDown);
      window.removeEventListener('keyup', handleKeyUp);
    };
  }, [isRecording, handleKeyDown, handleKeyUp, sessionStartTime, toast]);
  
  // Toggle recording state
  const toggleRecording = useCallback(() => {
    setIsRecording(prev => !prev);
    
    if (!isRecording) {
      // Starting recording
      toast({
        title: "Recording started",
        description: "Your keyboard activity is now being tracked."
      });
    } else {
      // Stopping recording
      toast({
        title: "Recording stopped",
        description: "Your keyboard activity is no longer being tracked."
      });
    }
  }, [isRecording, toast]);
  
  // Reset all data
  const resetData = () => {
    setActiveKeys(new Set());
    setKeyPressData({});
    setTotalKeyPresses(0);
    setKeyPressRate(0);
    setRecentKeyPresses([]);
    setSessionStartTime(isRecording ? Date.now() : null);
    
    // Reset history with zeros
    const initialHistory = Array.from({ length: 12 }, (_, i) => {
      const now = new Date();
      now.setSeconds(now.getSeconds() - (11 - i) * 5);
      return {
        time: now.toLocaleTimeString([], { 
          hour: '2-digit', 
          minute: '2-digit', 
          second: '2-digit',
          hour12: false 
        }),
        count: 0
      };
    });
    setKeyPressHistory(initialHistory);
    
    toast({
      title: "Data reset",
      description: "All keyboard tracking data has been reset."
    });
  };
  
  // Get most pressed keys
  const getMostPressedKeys = () => {
    return Object.entries(keyPressData)
      .map(([key, count]) => ({ key, count }))
      .sort((a, b) => b.count - a.count);
  };
  
  // Handle typing test completion
  const handleTypingTestComplete = (wpm: number, accuracy: number) => {
    const newResult = { wpm, accuracy, date: new Date() };
    setTypingResults(prev => [...prev, newResult]);
    
    toast({
      title: "Typing Test Completed",
      description: `Your score: ${wpm} WPM with ${accuracy}% accuracy.`
    });
  };
  
  
  return (
    <div className="flex flex-col min-h-screen bg-gradient-to-br from-background to-background/80">
      <Header 
        isRecording={isRecording} 
        totalKeyPresses={totalKeyPresses} 
        onToggleRecording={toggleRecording}
        onReset={resetData}
      />
      
      <main className="flex-1 container py-8">
        <div className="mb-8">
          <Tabs defaultValue="keyboard" className="animate-fadeIn">
            <TabsList className="mb-4 w-full justify-start gap-2">
              <TabsTrigger value="keyboard" className="transition-all duration-300">Typing</TabsTrigger>
              <TabsTrigger value="typing" className="transition-all duration-300">Typing Test</TabsTrigger>
              <TabsTrigger value="history" className="transition-all duration-300">History</TabsTrigger>
            </TabsList>
            
            <TabsContent value="keyboard" className="animate-fadeIn">
              <div className="glass-panel p-6 rounded-xl shadow-lg transition-all duration-300 hover:shadow-primary/5">
                <h2 className="text-xl font-semibold mb-4 flex items-center gap-2">
                  <Keyboard className="h-5 w-5 text-primary" />
                  Typing Tracker
                </h2>
                <p className="text-muted-foreground mb-6">
                  {isRecording 
                    ? "Type anywhere to see your typing activity and stats in real-time."
                    : "Click 'Start Recording' to begin tracking your typing activity."
                  }
                </p>
                <KeyboardHeatmap activeKeys={activeKeys} keyPressData={keyPressData} />
              </div>
            </TabsContent>
            
            <TabsContent value="typing" className="animate-fadeIn">
              <TypingTest onComplete={handleTypingTestComplete} />
              
              {typingResults.length > 0 && (
                <div className="mt-6 glass-panel p-6 rounded-xl shadow-lg">
                  <h2 className="text-lg font-semibold mb-4">Previous Results</h2>
                  <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
                    {typingResults.slice().reverse().map((result, idx) => (
                      <div key={idx} className="p-4 bg-card/70 rounded-lg border border-border">
                        <div className="flex justify-between items-center mb-2">
                          <span className="font-medium">{result.wpm} WPM</span>
                          <span className="text-sm text-muted-foreground">
                            {result.date.toLocaleTimeString([], {
                              hour: '2-digit',
                              minute: '2-digit',
                              hour12: false
                            })}
                          </span>
                        </div>
                        <div className="text-sm">Accuracy: {result.accuracy}%</div>
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </TabsContent>
            
            <TabsContent value="history" className="animate-fadeIn">
              <div className="glass-panel p-6 rounded-xl shadow-lg transition-all duration-300 hover:shadow-primary/5">
                <h2 className="text-xl font-semibold mb-4 flex items-center gap-2">
                  <Clock className="h-5 w-5 text-primary" />
                  Key Press History
                </h2>
                <p className="text-muted-foreground mb-6">
                  See your most recent key presses and their timestamps.
                </p>
                <KeyHistory recentKeyPresses={recentKeyPresses} />
              </div>
            </TabsContent>
          </Tabs>
        </div>
        
        {!isRecording && totalKeyPresses === 0 && (
          <div className="text-center my-12 p-8 glass-panel rounded-xl shadow-lg">
            <h2 className="text-2xl font-bold mb-2">Welcome to KeyTracker</h2>
            <p className="text-muted-foreground mb-6 max-w-2xl mx-auto">
              This tool helps you analyze your keyboard typing patterns in real-time. Click the "Start Recording" 
              button above to begin tracking your keyboard activity, or try the Typing Test to assess your typing skills.
            </p>
            
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Button 
                onClick={toggleRecording}
                className="bg-primary text-primary-foreground hover:bg-primary/90 px-6 py-2 rounded-md transition-all duration-300"
              >
                <Eye className="mr-2 h-4 w-4" />
                Start Tracking Now
              </Button>
              
              <Button
                onClick={() => document.querySelector('[value="typing"]')?.dispatchEvent(new MouseEvent('click'))}
                variant="outline"
                className="transition-all duration-300"
              >
                <Keyboard className="mr-2 h-4 w-4" />
                Try Typing Test
              </Button>
            </div>
          </div>
        )}
      </main>
      
      <Footer />
    </div>
  );
};

export default Index;
