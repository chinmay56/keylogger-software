
import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Progress } from "@/components/ui/progress";
import { Keyboard, ChartLine, Clock } from "lucide-react";
import { useToast } from "@/hooks/use-toast";

interface TypingTestProps {
  onComplete: (wpm: number, accuracy: number) => void;
}

const TEXT_SAMPLES = [
  "The quick brown fox jumps over the lazy dog. Typing skills are essential for modern computer users. Practice regularly to improve your speed and accuracy.",
  "Programming requires attention to detail. Each character matters when writing code. Good typing helps developers focus on solving problems rather than searching for keys.",
  "Digital communication happens at the speed of thought. Being able to type quickly and accurately gives you an advantage in today's fast-paced world.",
  "Learning to touch type is a valuable skill that will serve you throughout your entire career. Invest the time to practice and you'll reap the benefits for years to come.",
  "Technology continues to evolve at a rapid pace. As interfaces change, the keyboard remains a constant input method. Mastering it is time well spent."
];

const TypingTest: React.FC<TypingTestProps> = ({ onComplete }) => {
  const [currentText, setCurrentText] = useState('');
  const [userText, setUserText] = useState('');
  const [isTestActive, setIsTestActive] = useState(false);
  const [startTime, setStartTime] = useState<number | null>(null);
  const [endTime, setEndTime] = useState<number | null>(null);
  const [wpm, setWpm] = useState(0);
  const [accuracy, setAccuracy] = useState(100);
  const [timeElapsed, setTimeElapsed] = useState(0);
  const [progress, setProgress] = useState(0);
  
  const { toast } = useToast();
  
  // Start a new typing test
  const startTest = () => {
    // Select random text sample
    const randomIndex = Math.floor(Math.random() * TEXT_SAMPLES.length);
    setCurrentText(TEXT_SAMPLES[randomIndex]);
    setUserText('');
    setIsTestActive(true);
    setStartTime(Date.now());
    setEndTime(null);
    setWpm(0);
    setAccuracy(100);
    setTimeElapsed(0);
    setProgress(0);
    
    toast({
      title: "Typing test started",
      description: "Type the text below as accurately and quickly as you can."
    });
  };
  
  // Calculate words per minute and accuracy
  const calculateResults = () => {
    if (!startTime || !endTime) return;
    
    const minutes = (endTime - startTime) / 60000;
    const words = userText.trim().split(/\s+/).length;
    const calculatedWpm = Math.round(words / minutes);
    
    // Calculate accuracy (character-based)
    let correctChars = 0;
    const minLength = Math.min(currentText.length, userText.length);
    
    for (let i = 0; i < minLength; i++) {
      if (currentText[i] === userText[i]) {
        correctChars++;
      }
    }
    
    const calculatedAccuracy = Math.round((correctChars / currentText.length) * 100);
    
    setWpm(calculatedWpm);
    setAccuracy(calculatedAccuracy);
    onComplete(calculatedWpm, calculatedAccuracy);
  };
  
  // Handle user input
  const handleTextChange = (e: React.ChangeEvent<HTMLTextAreaElement>) => {
    if (!isTestActive) return;
    
    const newText = e.target.value;
    setUserText(newText);
    
    // Calculate progress
    const newProgress = Math.min(100, Math.round((newText.length / currentText.length) * 100));
    setProgress(newProgress);
    
    // Check if test is complete
    if (newText.length >= currentText.length) {
      setEndTime(Date.now());
      setIsTestActive(false);
    }
  };
  
  // Update time elapsed
  useEffect(() => {
    if (!isTestActive || !startTime) return;
    
    const timer = setInterval(() => {
      const elapsed = Math.floor((Date.now() - startTime) / 1000);
      setTimeElapsed(elapsed);
    }, 1000);
    
    return () => clearInterval(timer);
  }, [isTestActive, startTime]);
  
  // Calculate results when test ends
  useEffect(() => {
    if (endTime) {
      calculateResults();
    }
  }, [endTime]);
  
  // Format time as mm:ss
  const formatTime = (seconds: number): string => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
  };

  return (
    <Card className="glass-panel">
      <CardHeader className="pb-2">
        <CardTitle className="flex items-center gap-2">
          <Keyboard className="h-5 w-5" />
          Typing Skill Test
        </CardTitle>
        <CardDescription>
          Test your typing speed and accuracy with AI-generated text
        </CardDescription>
      </CardHeader>
      
      <CardContent>
        {!isTestActive && !endTime && (
          <div className="flex flex-col items-center gap-4 py-8">
            <p className="text-center text-muted-foreground">
              Test your typing speed and accuracy with our typing test.
              You'll be given a text to type as quickly and accurately as possible.
            </p>
            <Button onClick={startTest} className="animate-pulse">Start Typing Test</Button>
          </div>
        )}
        
        {(isTestActive || endTime) && (
          <div className="space-y-4">
            <div className="flex items-center justify-between mb-2">
              <div className="flex items-center gap-2">
                <Clock className="h-4 w-4" />
                <span className="text-sm font-medium">Time: {formatTime(timeElapsed)}</span>
              </div>
              <div className="flex items-center gap-2">
                <ChartLine className="h-4 w-4" />
                <span className="text-sm font-medium">Progress: {progress}%</span>
              </div>
            </div>
            
            <Progress value={progress} className="mb-4" />
            
            <div className="p-3 bg-muted/30 rounded-md mb-4 text-sm">
              {currentText}
            </div>
            
            <Textarea 
              value={userText}
              onChange={handleTextChange}
              placeholder="Start typing here..."
              className="min-h-[100px] focus:border-primary"
              disabled={!isTestActive}
            />
            
            {endTime && (
              <div className="mt-4 p-4 border border-border rounded-md bg-card/50">
                <h3 className="font-medium mb-2">Results</h3>
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <p className="text-sm text-muted-foreground">Speed</p>
                    <p className="text-2xl font-bold">{wpm} <span className="text-sm font-normal">WPM</span></p>
                  </div>
                  <div>
                    <p className="text-sm text-muted-foreground">Accuracy</p>
                    <p className="text-2xl font-bold">{accuracy}<span className="text-sm font-normal">%</span></p>
                  </div>
                </div>
                <Button onClick={startTest} className="w-full mt-4">Try Again</Button>
              </div>
            )}
          </div>
        )}
      </CardContent>
    </Card>
  );
};

export default TypingTest;
