
import React from 'react';
import { cn } from '@/lib/utils';
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Eye, EyeOff, Keyboard } from "lucide-react";

interface HeaderProps {
  isRecording: boolean;
  totalKeyPresses: number;
  onToggleRecording: () => void;
  onReset: () => void;
}

const Header: React.FC<HeaderProps> = ({
  isRecording,
  totalKeyPresses,
  onToggleRecording,
  onReset
}) => {
  return (
    <header className="border-b border-border">
      <div className="container py-4 flex flex-col md:flex-row justify-between items-center">
        <div className="flex items-center mb-4 md:mb-0">
          <Keyboard className="h-8 w-8 mr-3 text-primary" />
          <div>
            <h1 className="text-2xl font-bold tracking-tight">KeyTracker</h1>
            <p className="text-muted-foreground">Keyboard diagnostic tool</p>
          </div>
        </div>
        
        <div className="flex items-center gap-4">
          <Badge 
            variant="outline" 
            className={cn(
              "px-3 py-1 text-sm",
              isRecording ? "bg-destructive/20 text-destructive" : "bg-muted text-muted-foreground"
            )}
          >
            {isRecording ? 'Recording' : 'Paused'}
          </Badge>
          
          <Badge variant="outline" className="px-3 py-1 text-sm">
            {totalKeyPresses} keys
          </Badge>
          
          <Button
            variant={isRecording ? "destructive" : "default"}
            size="sm"
            onClick={onToggleRecording}
          >
            {isRecording ? (
              <>
                <EyeOff className="h-4 w-4 mr-2" />
                Stop Recording
              </>
            ) : (
              <>
                <Eye className="h-4 w-4 mr-2" />
                Start Recording
              </>
            )}
          </Button>
          
          <Button
            variant="outline"
            size="sm"
            onClick={onReset}
          >
            Reset Data
          </Button>
        </div>
      </div>
    </header>
  );
};

export default Header;
