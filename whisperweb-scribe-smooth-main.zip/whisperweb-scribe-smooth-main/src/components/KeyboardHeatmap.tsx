
import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Button } from "@/components/ui/button";
import { Copy } from "lucide-react";
import { useToast } from "@/hooks/use-toast";

type KeyboardHeatmapProps = { 
  activeKeys: Set<string>; 
  keyPressData: Record<string, number>;
};

// AI-generated text samples
const TEXT_SAMPLES = [
  "The quick brown fox jumps over the lazy dog. Typing skills are essential for modern computer users. Practice regularly to improve your speed and accuracy.",
  "Programming requires attention to detail. Each character matters when writing code. Good typing helps developers focus on solving problems rather than searching for keys.",
  "Digital communication happens at the speed of thought. Being able to type quickly and accurately gives you an advantage in today's fast-paced world.",
  "Learning to touch type is a valuable skill that will serve you throughout your entire career. Invest the time to practice and you'll reap the benefits for years to come.",
  "Technology continues to evolve at a rapid pace. As interfaces change, the keyboard remains a constant input method. Mastering it is time well spent."
];

const KeyboardHeatmap = ({ 
  activeKeys, 
  keyPressData 
}: KeyboardHeatmapProps) => {
  const [typingText, setTypingText] = useState<string>("");
  const [sampleText, setSampleText] = useState<string>("");
  const [textMatchPercentage, setTextMatchPercentage] = useState(0);
  const { toast } = useToast();
  
  // Calculate total key presses
  const totalKeyPresses = Object.values(keyPressData).reduce((sum, count) => sum + count, 0);
  
  // Find most pressed keys
  const mostPressedKeys = Object.entries(keyPressData)
    .map(([key, count]) => ({ key, count }))
    .sort((a, b) => b.count - a.count)
    .slice(0, 5);
  
  // Generate new sample text
  const generateNewSample = () => {
    const randomIndex = Math.floor(Math.random() * TEXT_SAMPLES.length);
    setSampleText(TEXT_SAMPLES[randomIndex]);
    setTypingText("");
    setTextMatchPercentage(0);
  };
  
  // Copy sample text to clipboard
  const copyToClipboard = () => {
    navigator.clipboard.writeText(sampleText);
    toast({
      title: "Copied to clipboard",
      description: "The sample text has been copied to your clipboard."
    });
  };
    
  // Update typing text when component mounts
  useEffect(() => {
    const handleKeyPress = (e: KeyboardEvent) => {
      if (!e.ctrlKey && !e.altKey && !e.metaKey) {
        if (e.key === 'Backspace') {
          setTypingText(prev => prev.slice(0, -1));
        } else if (e.key === 'Enter') {
          setTypingText(prev => prev + '\n');
        } else if (e.key.length === 1) {
          setTypingText(prev => prev + e.key);
        }
      }
    };
    
    window.addEventListener('keydown', handleKeyPress);
    return () => {
      window.removeEventListener('keydown', handleKeyPress);
    };
  }, []);
  
  // Set initial sample text
  useEffect(() => {
    if (!sampleText) {
      generateNewSample();
    }
  }, [sampleText]);
  
  // Calculate text match percentage
  useEffect(() => {
    if (sampleText) {
      // Calculate how many characters match
      let matchCount = 0;
      for (let i = 0; i < Math.min(typingText.length, sampleText.length); i++) {
        if (typingText[i] === sampleText[i]) {
          matchCount++;
        }
      }
      
      const percentage = Math.round((matchCount / sampleText.length) * 100);
      setTextMatchPercentage(percentage);
    }
  }, [typingText, sampleText]);
  
  return (
    <div className="grid grid-cols-1 gap-4">
      <Card className="shadow-lg">
        <CardHeader className="pb-3">
          <CardTitle className="flex items-center justify-between">
            <span>Practice Text</span>
            <div className="flex gap-2">
              <Button variant="outline" size="sm" onClick={generateNewSample}>
                New Text
              </Button>
              <Button variant="outline" size="sm" onClick={copyToClipboard}>
                <Copy className="h-4 w-4 mr-1" /> Copy
              </Button>
            </div>
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="p-4 border rounded-md bg-muted/20 font-mono text-sm mb-4">
            {sampleText}
          </div>
          <ScrollArea className="h-[150px] border rounded-md bg-background p-4 font-mono text-sm">
            {typingText || (
              <span className="text-muted-foreground italic">Start typing to see your text here...</span>
            )}
            <span className="animate-pulse ml-1">|</span>
          </ScrollArea>
        </CardContent>
      </Card>
      
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
        <Card className="shadow-md">
          <CardHeader className="pb-2">
            <CardTitle className="text-lg">Session Stats</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-2">
              <div className="flex justify-between items-center">
                <span className="text-muted-foreground">Total Key Presses</span>
                <span className="text-lg font-semibold">{totalKeyPresses}</span>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-muted-foreground">Unique Keys</span>
                <span className="text-lg font-semibold">{Object.keys(keyPressData).length}</span>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-muted-foreground">Characters Typed</span>
                <span className="text-lg font-semibold">{typingText.length}</span>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-muted-foreground">Text Match</span>
                <span className="text-lg font-semibold">{textMatchPercentage}%</span>
              </div>
            </div>
          </CardContent>
        </Card>
        
        <Card className="shadow-md">
          <CardHeader className="pb-2">
            <CardTitle className="text-lg">Most Used Keys</CardTitle>
          </CardHeader>
          <CardContent>
            {mostPressedKeys.length > 0 ? (
              <div className="space-y-2">
                {mostPressedKeys.map(({ key, count }) => (
                  <div key={key} className="flex justify-between items-center">
                    <span className="bg-secondary rounded-md px-2 py-1">{key}</span>
                    <span>{count} presses</span>
                  </div>
                ))}
              </div>
            ) : (
              <div className="text-muted-foreground text-center py-2">
                No key presses recorded yet
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    </div>
  );
};

export default KeyboardHeatmap;
