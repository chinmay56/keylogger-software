
import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Progress } from "@/components/ui/progress";
import { 
  LineChart, 
  Line, 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  ResponsiveContainer,
  Tooltip,
  Area,
  AreaChart 
} from 'recharts';

interface KeyStatsProps {
  totalKeyPresses: number;
  keyPressRate: number;
  mostPressedKeys: { key: string; count: number }[];
  keyPressHistory: { time: string; count: number }[];
}

const KeyStats: React.FC<KeyStatsProps> = ({
  totalKeyPresses,
  keyPressRate,
  mostPressedKeys,
  keyPressHistory
}) => {
  // Find max count for normalization
  const maxCount = mostPressedKeys.length > 0 ? mostPressedKeys[0].count : 0;
  
  return (
    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
      <Card>
        <CardHeader className="pb-2">
          <CardTitle className="text-lg font-medium">Session Summary</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            <div>
              <div className="flex items-center justify-between mb-1">
                <span className="text-sm font-medium">Total Key Presses</span>
                <span className="text-lg font-bold text-primary">{totalKeyPresses}</span>
              </div>
            </div>
            
            <div>
              <div className="flex items-center justify-between mb-1">
                <span className="text-sm font-medium">Press Rate (per minute)</span>
                <span className="text-lg font-bold text-primary">{keyPressRate.toFixed(1)}</span>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>
      
      <Card>
        <CardHeader className="pb-2">
          <CardTitle className="text-lg font-medium">Most Pressed Keys</CardTitle>
        </CardHeader>
        <CardContent className="space-y-3">
          {mostPressedKeys.slice(0, 5).map((keyData) => (
            <div key={keyData.key}>
              <div className="flex items-center justify-between mb-1">
                <span className="text-sm font-medium">{keyData.key}</span>
                <span className="text-sm">{keyData.count}</span>
              </div>
              <Progress value={(keyData.count / maxCount) * 100} className="h-2" />
            </div>
          ))}
        </CardContent>
      </Card>
      
      <Card className="md:col-span-2">
        <CardHeader className="pb-2">
          <CardTitle className="text-lg font-medium">Key Press Activity</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="chart-container">
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={keyPressHistory}>
                <defs>
                  <linearGradient id="colorCount" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="hsl(var(--primary))" stopOpacity={0.8}/>
                    <stop offset="95%" stopColor="hsl(var(--primary))" stopOpacity={0.2}/>
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" />
                <XAxis 
                  dataKey="time" 
                  stroke="hsl(var(--muted-foreground))"
                  fontSize={12} 
                  tickFormatter={(value) => value}
                />
                <YAxis 
                  stroke="hsl(var(--muted-foreground))"
                  fontSize={12}
                />
                <Tooltip 
                  contentStyle={{ 
                    backgroundColor: 'hsl(var(--card))',
                    border: '1px solid hsl(var(--border))',
                    borderRadius: '8px'
                  }}
                  labelStyle={{ color: 'hsl(var(--foreground))' }}
                />
                <Area 
                  type="monotone" 
                  dataKey="count" 
                  stroke="hsl(var(--primary))" 
                  fillOpacity={1}
                  fill="url(#colorCount)"
                />
              </AreaChart>
            </ResponsiveContainer>
          </div>
        </CardContent>
      </Card>
    </div>
  );
};

export default KeyStats;
