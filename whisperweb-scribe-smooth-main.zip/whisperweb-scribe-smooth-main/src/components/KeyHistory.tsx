
import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { ScrollArea } from "@/components/ui/scroll-area";

interface KeyPress {
  key: string;
  timestamp: number;
}

interface KeyHistoryProps {
  recentKeyPresses: KeyPress[];
}

const KeyHistory: React.FC<KeyHistoryProps> = ({ recentKeyPresses }) => {
  return (
    <Card>
      <CardHeader className="pb-2">
        <CardTitle className="text-lg font-medium">Recent Key Presses</CardTitle>
      </CardHeader>
      <CardContent>
        <ScrollArea className="h-[200px]">
          <div className="space-y-2">
            {recentKeyPresses.map((keyPress, index) => {
              const date = new Date(keyPress.timestamp);
              const formattedTime = date.toLocaleTimeString([], { 
                hour: '2-digit', 
                minute: '2-digit',
                second: '2-digit',
                hour12: false
              });
              
              return (
                <div 
                  key={index} 
                  className="flex justify-between items-center p-2 rounded-md bg-secondary/50 animate-fadeIn"
                  style={{ animationDelay: `${index * 50}ms` }}
                >
                  <div className="flex items-center">
                    <span className="inline-flex items-center justify-center bg-primary/20 text-primary rounded w-8 h-8 mr-3">
                      {keyPress.key}
                    </span>
                    <span>{keyPress.key === " " ? "Space" : keyPress.key}</span>
                  </div>
                  <span className="text-muted-foreground text-xs">{formattedTime}</span>
                </div>
              );
            })}
            {recentKeyPresses.length === 0 && (
              <div className="text-center text-muted-foreground p-4">
                No key presses recorded yet
              </div>
            )}
          </div>
        </ScrollArea>
      </CardContent>
    </Card>
  );
};

export default KeyHistory;
